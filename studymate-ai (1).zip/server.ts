import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialized Gemini client
let aiClient: GoogleGenAI | null = null;
function getAI() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY || "";
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", app: "StudyMate AI" });
});

// AI Study Plan Generator Endpoint
app.post("/api/ai/suggest-plan", async (req, res) => {
  try {
    const { subject, examDate, availableHours, goal, currentLevel, topicsToCover } = req.body;
    
    if (!process.env.GEMINI_API_KEY) {
      // Fallback response if key is missing
      return res.json({
        title: `Custom Study Plan for ${subject || "General Studies"}`,
        summary: "Here is a structured study plan created for your goals.",
        schedule: [
          { day: "Day 1", time: "1.5 hours", focus: "Core Concepts & Fundamentals", activity: "Review key formulas and chapter summaries" },
          { day: "Day 2", time: "2 hours", focus: "Deep Dive & Problem Solving", activity: "Solve 10 practice problems and make flashcards" },
          { day: "Day 3", time: "1 hour", focus: "Active Recall & Self Quiz", activity: "Test yourself on Day 1 & 2 topics" },
          { day: "Day 4", time: "1.5 hours", focus: "Weak Areas & Review", activity: "Re-check missed questions and refine notes" },
        ],
        tips: ["Use 25-min Pomodoro sessions", "Teach concepts aloud to verify understanding", "Take a 5-min walk between sessions"]
      });
    }

    const ai = getAI();
    const prompt = `Create a highly structured personalized study plan for a student:
- Subject: ${subject || "General"}
- Target Goal/Grade: ${goal || "A Grade / High Comprehension"}
- Exam/Deadline: ${examDate || "Upcoming in 1-2 weeks"}
- Daily Available Hours: ${availableHours || "2 hours"}
- Current Understanding Level: ${currentLevel || "Intermediate"}
- Specific Topics to Cover: ${topicsToCover || "All syllabus chapters"}

Provide a detailed structured study schedule with actionable daily sessions, break advice, active learning techniques, and key focus milestones. Return strictly valid JSON matching the schema.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: "Title of the study plan" },
            summary: { type: Type.STRING, description: "Brief high-level overview of the strategy" },
            schedule: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  day: { type: Type.STRING, description: "Day label (e.g. Day 1, Monday)" },
                  time: { type: Type.STRING, description: "Suggested study duration (e.g. 45 mins)" },
                  focus: { type: Type.STRING, description: "Core topic or focus area" },
                  activity: { type: Type.STRING, description: "Actionable study technique or task" },
                },
                required: ["day", "time", "focus", "activity"],
              },
            },
            tips: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Pro study strategies tailored to this topic",
            },
            milestones: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Checkpoints to assess readiness",
            }
          },
          required: ["title", "summary", "schedule", "tips"],
        },
      },
    });

    const jsonText = response.text?.trim() || "{}";
    const parsedData = JSON.parse(jsonText);
    res.json(parsedData);
  } catch (err: any) {
    console.error("Error generating study plan:", err);
    res.status(500).json({ error: err.message || "Failed to generate AI study plan" });
  }
});

// AI Topic Explainer Endpoint
app.post("/api/ai/explain-topic", async (req, res) => {
  try {
    const { topic, subject, level, style } = req.body;

    if (!topic) {
      return res.status(400).json({ error: "Topic is required" });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.json({
        topic: topic,
        summary: `Overview of ${topic} in ${subject || "General Studies"}`,
        explanation: `${topic} is a key concept in ${subject || "this subject"}. Imagine it as a modular system where components interact according to underlying principles. Breaking it down helps build strong intuitive understanding.`,
        analogies: ["Think of it like building blocks forming a complete structure."],
        keyTakeaways: [
          "Understand the core definitions and terms.",
          "Identify how inputs transform into outputs.",
          "Practice applying the concept to simple real-world scenarios."
        ],
        flashcards: [
          { question: `What is the core definition of ${topic}?`, answer: "The primary principle that governs how the system operates." },
          { question: `Why is ${topic} important?`, answer: "It serves as the foundation for solving complex problems in this field." }
        ],
        practiceQuiz: [
          {
            question: `Which statement best describes ${topic}?`,
            options: ["A core foundational concept", "An obsolete theory", "A random calculation", "None of the above"],
            correctAnswer: 0,
            explanation: `${topic} is indeed a foundational concept.`
          }
        ]
      });
    }

    const ai = getAI();
    const prompt = `Explain the following study topic for a student:
- Topic: ${topic}
- Subject: ${subject || "General"}
- Target Understanding Level: ${level || "Intermediate"}
- Preferred Learning Style: ${style || "Analogy & Step-by-Step"}

Provide a clear, engaging explanation with real-world analogies, core key takeaways, interactive flashcards, and a 3-question self-test practice quiz. Return strictly valid JSON matching the schema.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            topic: { type: Type.STRING },
            summary: { type: Type.STRING, description: "One-sentence executive summary" },
            explanation: { type: Type.STRING, description: "Detailed Markdown-formatted explanation" },
            analogies: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Intuitive analogies or metaphors"
            },
            keyTakeaways: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "3-5 bullet point highlights"
            },
            flashcards: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  question: { type: Type.STRING },
                  answer: { type: Type.STRING }
                },
                required: ["question", "answer"]
              }
            },
            practiceQuiz: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  question: { type: Type.STRING },
                  options: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  },
                  correctAnswer: { type: Type.INTEGER, description: "0-based index of correct option" },
                  explanation: { type: Type.STRING }
                },
                required: ["question", "options", "correctAnswer", "explanation"]
              }
            }
          },
          required: ["topic", "summary", "explanation", "keyTakeaways", "flashcards", "practiceQuiz"]
        }
      }
    });

    const jsonText = response.text?.trim() || "{}";
    const parsedData = JSON.parse(jsonText);
    res.json(parsedData);
  } catch (err: any) {
    console.error("Error explaining topic:", err);
    res.status(500).json({ error: err.message || "Failed to generate topic explanation" });
  }
});

// AI General Assistant Chat Endpoint
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { messages, userPrompt } = req.body;

    if (!userPrompt) {
      return res.status(400).json({ error: "User prompt is required" });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.json({
        reply: `[AI Study Buddy Demo Response] You asked: "${userPrompt}". \n\nTip: Connect your Gemini API Key in AI Studio Settings to activate full live AI model capabilities! In the meantime, try creating study tasks, tracking assignments, or generating local practice flashcards.`
      });
    }

    const ai = getAI();
    
    // Format conversation history
    const historyText = Array.isArray(messages)
      ? messages.slice(-6).map((m: any) => `${m.role === 'user' ? 'Student' : 'StudyMate AI'}: ${m.content}`).join('\n')
      : '';

    const fullPrompt = `${historyText ? `Previous conversation:\n${historyText}\n\n` : ''}Student: ${userPrompt}\nStudyMate AI:`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: fullPrompt,
      config: {
        systemInstruction: "You are StudyMate AI, an encouraging, highly effective, and structured AI Study Buddy for students. Keep explanations clear, actionable, concise, friendly, and formatted nicely with markdown bullet points where appropriate.",
        temperature: 0.7,
      }
    });

    res.json({ reply: response.text || "I'm here to help with your study tasks! Could you rephrase your question?" });
  } catch (err: any) {
    console.error("Error in AI chat:", err);
    res.status(500).json({ error: err.message || "AI Assistant service error" });
  }
});

// Express + Vite server start function
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`StudyMate AI server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
