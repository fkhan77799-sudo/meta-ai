import { StudyTask, Assignment, DailyScheduleSlot, UserSettings, StudyLog } from '../types';

const KEYS = {
  TASKS: 'studymate_tasks_v1',
  ASSIGNMENTS: 'studymate_assignments_v1',
  SCHEDULE: 'studymate_schedule_v1',
  SETTINGS: 'studymate_settings_v1',
  STUDY_LOGS: 'studymate_logs_v1',
  AI_PLANS: 'studymate_ai_plans_v1',
  THEME: 'studymate_theme_v1',
};

// Seed default data
const defaultTasks: StudyTask[] = [
  {
    id: 'task-1',
    title: 'Review Chapter 4: Neural Networks & Backpropagation',
    subject: 'Artificial Intelligence',
    dueDate: new Date(Date.now() + 86400000).toISOString().split('T')[0], // Tomorrow
    estimatedMinutes: 60,
    priority: 'high',
    status: 'in_progress',
    notes: 'Focus on understanding gradient descent mathematical derivation.',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'task-2',
    title: 'Complete Linear Algebra Problem Set 3',
    subject: 'Mathematics',
    dueDate: new Date(Date.now() + 172800000).toISOString().split('T')[0],
    estimatedMinutes: 90,
    priority: 'high',
    status: 'todo',
    notes: 'Eigenvalues and Eigenvectors questions 1 through 8.',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'task-3',
    title: 'Read Operating Systems Research Paper on Paging',
    subject: 'Computer Science',
    dueDate: new Date(Date.now() + 259200000).toISOString().split('T')[0],
    estimatedMinutes: 45,
    priority: 'medium',
    status: 'completed',
    notes: 'Annotated key virtual memory diagrams.',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'task-4',
    title: 'Draft Essay Outline for Ethics in AI',
    subject: 'Artificial Intelligence',
    dueDate: new Date(Date.now() + 345600000).toISOString().split('T')[0],
    estimatedMinutes: 30,
    priority: 'low',
    status: 'todo',
    notes: 'Include perspectives on algorithmic bias and data transparency.',
    createdAt: new Date().toISOString(),
  }
];

const defaultAssignments: Assignment[] = [
  {
    id: 'assg-1',
    title: 'Final Project: Gemini AI Application',
    course: 'AI & Machine Learning 101',
    dueDate: new Date(Date.now() + 5 * 86400000).toISOString().split('T')[0],
    weightPercentage: 25,
    status: 'in_progress',
    gradeScore: undefined,
    maxScore: 100,
    instructions: 'Build a production-ready web app leveraging Google Gemini API.',
  },
  {
    id: 'assg-2',
    title: 'Midterm Exam - Data Structures & Algorithms',
    course: 'Computer Science II',
    dueDate: new Date(Date.now() + 2 * 86400000).toISOString().split('T')[0],
    weightPercentage: 20,
    status: 'not_started',
    instructions: 'Comprehensive exam covering Trees, Graphs, Sorting, and Big O analysis.',
  },
  {
    id: 'assg-3',
    title: 'Lab Report 2: Signal Processing Analysis',
    course: 'Digital Signal Processing',
    dueDate: new Date(Date.now() - 86400000).toISOString().split('T')[0], // Yesterday
    weightPercentage: 10,
    status: 'graded',
    gradeScore: 94,
    maxScore: 100,
    instructions: 'Analyze Fourier transforms in MATLAB/Python.',
  },
];

const defaultSchedule: DailyScheduleSlot[] = [
  { id: 'slot-1', timeSlot: '08:00 AM - 09:00 AM', subject: 'Artificial Intelligence', topic: 'Neural Net Mathematics', completed: true, notes: 'Reviewed loss functions' },
  { id: 'slot-2', timeSlot: '09:30 AM - 11:00 AM', subject: 'Mathematics', topic: 'Linear Algebra Matrix Transformations', completed: true },
  { id: 'slot-3', timeSlot: '01:00 PM - 02:30 PM', subject: 'Computer Science', topic: 'Binary Search Trees & Heap Implementation', completed: false, notes: 'Practice coding in IDE' },
  { id: 'slot-4', timeSlot: '03:00 PM - 04:00 PM', subject: 'AI Assistant Session', topic: 'Ask Gemini to explain Backpropagation with visual analogies', completed: false },
  { id: 'slot-5', timeSlot: '05:00 PM - 06:00 PM', subject: 'Revision & Quiz', topic: 'Self-test flashcards on today\'s concepts', completed: false },
];

const defaultSettings: UserSettings = {
  userName: 'Alex Chen',
  email: 'alex.student@university.edu',
  schoolOrCourse: 'Computer Science & AI Major',
  targetGpa: '3.8',
  dailyGoalHours: 3.5,
  defaultPomodoroWork: 25,
  defaultPomodoroBreak: 5,
  theme: 'light',
  notificationsEnabled: true,
  aiStylePreference: 'Analogy & Step-by-Step',
};

const defaultLogs: StudyLog[] = [
  { id: 'log-1', subject: 'Artificial Intelligence', durationMinutes: 60, date: new Date().toISOString().split('T')[0] },
  { id: 'log-2', subject: 'Mathematics', durationMinutes: 90, date: new Date(Date.now() - 86400000).toISOString().split('T')[0] },
  { id: 'log-3', subject: 'Computer Science', durationMinutes: 45, date: new Date(Date.now() - 172800000).toISOString().split('T')[0] },
];

export function getStoredTasks(): StudyTask[] {
  try {
    const data = localStorage.getItem(KEYS.TASKS);
    return data ? JSON.parse(data) : defaultTasks;
  } catch {
    return defaultTasks;
  }
}

export function saveTasks(tasks: StudyTask[]) {
  localStorage.setItem(KEYS.TASKS, JSON.stringify(tasks));
}

export function getStoredAssignments(): Assignment[] {
  try {
    const data = localStorage.getItem(KEYS.ASSIGNMENTS);
    return data ? JSON.parse(data) : defaultAssignments;
  } catch {
    return defaultAssignments;
  }
}

export function saveAssignments(assignments: Assignment[]) {
  localStorage.setItem(KEYS.ASSIGNMENTS, JSON.stringify(assignments));
}

export function getStoredSchedule(): DailyScheduleSlot[] {
  try {
    const data = localStorage.getItem(KEYS.SCHEDULE);
    return data ? JSON.parse(data) : defaultSchedule;
  } catch {
    return defaultSchedule;
  }
}

export function saveSchedule(schedule: DailyScheduleSlot[]) {
  localStorage.setItem(KEYS.SCHEDULE, JSON.stringify(schedule));
}

export function getStoredSettings(): UserSettings {
  try {
    const data = localStorage.getItem(KEYS.SETTINGS);
    return data ? JSON.parse(data) : defaultSettings;
  } catch {
    return defaultSettings;
  }
}

export function saveSettings(settings: UserSettings) {
  localStorage.setItem(KEYS.SETTINGS, JSON.stringify(settings));
}

export function getStoredStudyLogs(): StudyLog[] {
  try {
    const data = localStorage.getItem(KEYS.STUDY_LOGS);
    return data ? JSON.parse(data) : defaultLogs;
  } catch {
    return defaultLogs;
  }
}

export function saveStudyLogs(logs: StudyLog[]) {
  localStorage.setItem(KEYS.STUDY_LOGS, JSON.stringify(logs));
}

export function resetAllData() {
  localStorage.removeItem(KEYS.TASKS);
  localStorage.removeItem(KEYS.ASSIGNMENTS);
  localStorage.removeItem(KEYS.SCHEDULE);
  localStorage.removeItem(KEYS.SETTINGS);
  localStorage.removeItem(KEYS.STUDY_LOGS);
  localStorage.removeItem(KEYS.AI_PLANS);
}
