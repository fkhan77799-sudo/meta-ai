import React, { useState } from 'react';
import {
  Sparkles,
  BookOpen,
  Calendar,
  MessageSquare,
  Send,
  HelpCircle,
  CheckCircle,
  XCircle,
  RotateCcw,
  Plus,
  Zap,
  Check,
  Brain,
  Lightbulb,
} from 'lucide-react';
import {
  AIStudyPlan,
  TopicExplanation,
  ChatMessage,
  DailyScheduleSlot,
  StudyTask,
} from '../types';

interface AIAssistantPageProps {
  onAddScheduleSlots?: (slots: DailyScheduleSlot[]) => void;
  onAddTask?: (task: Omit<StudyTask, 'id' | 'createdAt'>) => void;
}

type TabType = 'plan_generator' | 'topic_explainer' | 'study_chat';

export const AIAssistantPage: React.FC<AIAssistantPageProps> = ({
  onAddScheduleSlots,
  onAddTask,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('plan_generator');

  // Plan Generator State
  const [planSubject, setPlanSubject] = useState('Artificial Intelligence');
  const [planGoal, setPlanGoal] = useState('Master Neural Networks & Ace Midterm');
  const [planExamDate, setPlanExamDate] = useState('Next Week');
  const [planAvailableHours, setPlanAvailableHours] = useState('2 hours/day');
  const [planTopics, setPlanTopics] = useState('Backpropagation, Convolutional Nets, Transformers');
  const [isGeneratingPlan, setIsGeneratingPlan] = useState(false);
  const [generatedPlan, setGeneratedPlan] = useState<AIStudyPlan | null>(null);

  // Topic Explainer State
  const [topicName, setTopicName] = useState('Quantum Entanglement');
  const [topicSubject, setTopicSubject] = useState('Physics / Science');
  const [topicLevel, setTopicLevel] = useState('Intermediate');
  const [topicStyle, setTopicStyle] = useState('Analogy & Step-by-Step');
  const [isExplainingTopic, setIsExplainingTopic] = useState(false);
  const [explanationResult, setExplanationResult] = useState<TopicExplanation | null>(null);
  
  // Flashcard Flipper Index
  const [currentFlashcardIdx, setCurrentFlashcardIdx] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  // Quiz State
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});

  // Chatbot State
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-1',
      role: 'assistant',
      content:
        'Hello! I am **StudyMate AI**, your personal AI study assistant powered by Google Gemini. How can I help you today? You can ask me to explain concepts, generate study schedules, or create practice questions.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [userChatInput, setUserChatInput] = useState('');
  const [isSendingChat, setIsSendingChat] = useState(false);

  // Plan Generator API Call
  const handleGeneratePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGeneratingPlan(true);
    setGeneratedPlan(null);

    try {
      const res = await fetch('/api/ai/suggest-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject: planSubject,
          goal: planGoal,
          examDate: planExamDate,
          availableHours: planAvailableHours,
          topicsToCover: planTopics,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setGeneratedPlan(data);
      } else {
        alert(data.error || 'Failed to generate study plan');
      }
    } catch (err: any) {
      console.error(err);
      alert('Error connecting to Gemini API endpoint');
    } finally {
      setIsGeneratingPlan(false);
    }
  };

  // Topic Explainer API Call
  const handleExplainTopic = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topicName.trim()) return;

    setIsExplainingTopic(true);
    setExplanationResult(null);
    setCurrentFlashcardIdx(0);
    setIsFlipped(false);
    setQuizAnswers({});

    try {
      const res = await fetch('/api/ai/explain-topic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topicName,
          subject: topicSubject,
          level: topicLevel,
          style: topicStyle,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setExplanationResult(data);
      } else {
        alert(data.error || 'Failed to explain topic');
      }
    } catch (err: any) {
      console.error(err);
      alert('Error connecting to Gemini API endpoint');
    } finally {
      setIsExplainingTopic(false);
    }
  };

  // Chat API Call
  const handleSendChat = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!userChatInput.trim() || isSendingChat) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: userChatInput.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newMessages = [...chatMessages, userMsg];
    setChatMessages(newMessages);
    setUserChatInput('');
    setIsSendingChat(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages,
          userPrompt: userMsg.content,
        }),
      });

      const data = await res.json();
      const assistantMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: data.reply || 'I processed your question. How else can I assist your studies?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setChatMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      console.error(err);
      setChatMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'assistant',
          content: 'Sorry, I ran into an error connecting to the AI service. Please check your connection and try again.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsSendingChat(false);
    }
  };

  // Handle applying AI study schedule to Daily Planner
  const handleApplyScheduleToPlanner = () => {
    if (!generatedPlan || !onAddScheduleSlots) return;

    const newSlots: DailyScheduleSlot[] = generatedPlan.schedule.map((item, i) => ({
      id: `ai-slot-${Date.now()}-${i}`,
      timeSlot: item.time,
      subject: planSubject,
      topic: `${item.focus}: ${item.activity}`,
      completed: false,
    }));

    onAddScheduleSlots(newSlots);
    alert('AI Study Plan successfully exported to your Daily Planner!');
  };

  return (
    <div className="space-y-6 pb-12 animate-fadeIn">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-purple-700 via-indigo-700 to-indigo-800 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-xs font-semibold mb-2 backdrop-blur-md">
              <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin-slow" />
              <span>Google Gemini 3.6 Flash Engine</span>
            </div>
            <h2 className="text-2xl font-bold">AI Study Hub & Companion</h2>
            <p className="text-xs text-purple-100/90 mt-1">
              Generate personalized exam roadmaps, explain difficult concepts, and get instant answers
            </p>
          </div>

          {/* Tab Navigation Controls */}
          <div className="flex rounded-xl bg-white/10 p-1.5 backdrop-blur-md border border-white/20">
            <button
              onClick={() => setActiveTab('plan_generator')}
              className={`flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'plan_generator'
                  ? 'bg-white text-indigo-700 shadow-md'
                  : 'text-white hover:bg-white/10'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Study Planner</span>
            </button>

            <button
              onClick={() => setActiveTab('topic_explainer')}
              className={`flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'topic_explainer'
                  ? 'bg-white text-indigo-700 shadow-md'
                  : 'text-white hover:bg-white/10'
              }`}
            >
              <Brain className="w-3.5 h-3.5" />
              <span>Topic Explainer</span>
            </button>

            <button
              onClick={() => setActiveTab('study_chat')}
              className={`flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'study_chat'
                  ? 'bg-white text-indigo-700 shadow-md'
                  : 'text-white hover:bg-white/10'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>AI Study Buddy</span>
            </button>
          </div>
        </div>
      </div>

      {/* TAB 1: AI STUDY PLAN GENERATOR */}
      {activeTab === 'plan_generator' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Form (1 col) */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base mb-1 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-indigo-600" />
              <span>Study Plan Setup</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Configure parameters to generate a custom roadmap.
            </p>

            <form onSubmit={handleGeneratePlan} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Subject / Course
                </label>
                <input
                  type="text"
                  required
                  value={planSubject}
                  onChange={(e) => setPlanSubject(e.target.value)}
                  placeholder="e.g. Linear Algebra, Chemistry"
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Target Goal
                </label>
                <input
                  type="text"
                  required
                  value={planGoal}
                  onChange={(e) => setPlanGoal(e.target.value)}
                  placeholder="e.g. Pass Final Exam with A grade"
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Exam / Deadline
                  </label>
                  <input
                    type="text"
                    value={planExamDate}
                    onChange={(e) => setPlanExamDate(e.target.value)}
                    placeholder="In 2 weeks"
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Daily Hours
                  </label>
                  <input
                    type="text"
                    value={planAvailableHours}
                    onChange={(e) => setPlanAvailableHours(e.target.value)}
                    placeholder="2 hours/day"
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Key Topics / Chapters
                </label>
                <textarea
                  rows={3}
                  value={planTopics}
                  onChange={(e) => setPlanTopics(e.target.value)}
                  placeholder="List chapters or weak areas..."
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                />
              </div>

              <button
                type="submit"
                disabled={isGeneratingPlan}
                className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md shadow-indigo-500/20 flex items-center justify-center space-x-2 transition-all disabled:opacity-50"
              >
                {isGeneratingPlan ? (
                  <>
                    <Sparkles className="w-4 h-4 animate-spin" />
                    <span>Analyzing & Crafting Plan...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Generate AI Plan</span>
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Right Results (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            {!generatedPlan && !isGeneratingPlan && (
              <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 flex flex-col items-center justify-center min-h-[350px]">
                <Sparkles className="w-12 h-12 text-indigo-400 mb-3" />
                <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
                  Ready to Generate Your AI Study Roadmap
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mt-1">
                  Enter your subject and available daily hours on the left to receive a structured roadmap with daily schedules and active learning strategies.
                </p>
              </div>
            )}

            {isGeneratingPlan && (
              <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 flex flex-col items-center justify-center min-h-[350px]">
                <div className="w-12 h-12 rounded-full border-4 border-indigo-600 border-t-transparent animate-spin mb-4" />
                <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
                  Gemini is building your study plan...
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Structuring daily focus blocks, review milestones, and active recall sessions.
                </p>
              </div>
            )}

            {generatedPlan && (
              <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
                  <div>
                    <span className="px-2.5 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold text-xs">
                      {planSubject}
                    </span>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 mt-1">
                      {generatedPlan.title}
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                      {generatedPlan.summary}
                    </p>
                  </div>

                  {onAddScheduleSlots && (
                    <button
                      onClick={handleApplyScheduleToPlanner}
                      className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-md shadow-emerald-500/20 shrink-0 transition-all"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Export to Planner</span>
                    </button>
                  )}
                </div>

                {/* Daily Schedule List */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Daily Action Roadmap
                  </h4>

                  {generatedPlan.schedule.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex items-start justify-between gap-3"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-xs font-bold font-mono px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-950 text-indigo-800 dark:text-indigo-300">
                            {item.day}
                          </span>
                          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                            ({item.time})
                          </span>
                        </div>
                        <h5 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                          {item.focus}
                        </h5>
                        <p className="text-xs text-slate-600 dark:text-slate-400">
                          {item.activity}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Study Tips */}
                {generatedPlan.tips && generatedPlan.tips.length > 0 && (
                  <div className="p-4 rounded-xl bg-amber-50/60 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-900/40 space-y-2">
                    <div className="flex items-center space-x-2 text-amber-800 dark:text-amber-300 font-bold text-xs">
                      <Lightbulb className="w-4 h-4 text-amber-600" />
                      <span>Pro Study Strategies</span>
                    </div>
                    <ul className="list-disc list-inside space-y-1 text-xs text-amber-900/90 dark:text-amber-200/90">
                      {generatedPlan.tips.map((tip, i) => (
                        <li key={i}>{tip}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: AI TOPIC EXPLAINER & QUIZ */}
      {activeTab === 'topic_explainer' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Form */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base mb-1 flex items-center gap-2">
              <Brain className="w-4 h-4 text-indigo-600" />
              <span>Topic Explainer Setup</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Enter any concept to receive an intuitive explanation, flashcards, and a practice quiz.
            </p>

            <form onSubmit={handleExplainTopic} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Topic / Concept Name *
                </label>
                <input
                  type="text"
                  required
                  value={topicName}
                  onChange={(e) => setTopicName(e.target.value)}
                  placeholder="e.g. Backpropagation, Photosynthesis, Bayes Theorem"
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Subject / Field
                </label>
                <input
                  type="text"
                  value={topicSubject}
                  onChange={(e) => setTopicSubject(e.target.value)}
                  placeholder="e.g. Computer Science"
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Level
                  </label>
                  <select
                    value={topicLevel}
                    onChange={(e) => setTopicLevel(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                  >
                    <option value="Beginner (ELI5)">Beginner (ELI5)</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced College Level">Advanced College</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Explanation Style
                  </label>
                  <select
                    value={topicStyle}
                    onChange={(e) => setTopicStyle(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                  >
                    <option value="Analogy & Step-by-Step">Analogy & Steps</option>
                    <option value="Real-World Application">Real-World Examples</option>
                    <option value="Mathematical Rigor">Math & Formulas</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={isExplainingTopic}
                className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-semibold text-xs shadow-md shadow-purple-500/20 flex items-center justify-center space-x-2 transition-all disabled:opacity-50"
              >
                {isExplainingTopic ? (
                  <>
                    <Brain className="w-4 h-4 animate-pulse" />
                    <span>Generating Explanation...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Explain Topic & Quiz</span>
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Right Explanation Display */}
          <div className="lg:col-span-2 space-y-6">
            {!explanationResult && !isExplainingTopic && (
              <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 flex flex-col items-center justify-center min-h-[350px]">
                <Brain className="w-12 h-12 text-purple-400 mb-3" />
                <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
                  Topic Explainer Ready
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mt-1">
                  Type any subject or topic on the left to get clear metaphors, flashcards, and self-assessment test questions.
                </p>
              </div>
            )}

            {isExplainingTopic && (
              <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 flex flex-col items-center justify-center min-h-[350px]">
                <div className="w-12 h-12 rounded-full border-4 border-purple-600 border-t-transparent animate-spin mb-4" />
                <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
                  Gemini is constructing your topic breakdown...
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Formulating analogies, active recall flashcards, and a practice quiz.
                </p>
              </div>
            )}

            {explanationResult && (
              <div className="space-y-6">
                {/* Main Explanation Block */}
                <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
                    <span className="px-2.5 py-0.5 rounded-full bg-purple-50 dark:bg-purple-950 text-purple-700 dark:text-purple-300 font-bold text-xs">
                      {explanationResult.topic}
                    </span>
                    <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                      Summary
                    </span>
                  </div>

                  <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl">
                    {explanationResult.summary}
                  </p>

                  <div className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line space-y-2">
                    {explanationResult.explanation}
                  </div>

                  {/* Analogies */}
                  {explanationResult.analogies && explanationResult.analogies.length > 0 && (
                    <div className="p-3.5 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/40">
                      <div className="flex items-center space-x-2 text-indigo-700 dark:text-indigo-300 font-bold text-xs mb-1">
                        <Lightbulb className="w-4 h-4 text-indigo-600" />
                        <span>Metaphor / Analogy</span>
                      </div>
                      <p className="text-xs text-indigo-950 dark:text-indigo-200 italic">
                        "{explanationResult.analogies[0]}"
                      </p>
                    </div>
                  )}

                  {/* Key Takeaways */}
                  <div className="space-y-1.5 pt-2">
                    <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      Key Takeaways
                    </h4>
                    <ul className="space-y-1">
                      {explanationResult.keyTakeaways.map((item, idx) => (
                        <li key={idx} className="flex items-start space-x-2 text-xs text-slate-700 dark:text-slate-300">
                          <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Flashcard Widget */}
                {explanationResult.flashcards && explanationResult.flashcards.length > 0 && (
                  <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-2">
                        <Zap className="w-4 h-4 text-amber-500" />
                        <span>Interactive AI Flashcard ({currentFlashcardIdx + 1} of {explanationResult.flashcards.length})</span>
                      </h4>

                      <div className="flex items-center space-x-2 text-xs">
                        <button
                          onClick={() => {
                            setIsFlipped(false);
                            setCurrentFlashcardIdx((prev) => (prev > 0 ? prev - 1 : explanationResult.flashcards.length - 1));
                          }}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium"
                        >
                          Prev
                        </button>
                        <button
                          onClick={() => {
                            setIsFlipped(false);
                            setCurrentFlashcardIdx((prev) => (prev < explanationResult.flashcards.length - 1 ? prev + 1 : 0));
                          }}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium"
                        >
                          Next
                        </button>
                      </div>
                    </div>

                    {/* Flipper Card */}
                    <div
                      onClick={() => setIsFlipped(!isFlipped)}
                      className="min-h-[160px] p-6 rounded-2xl bg-gradient-to-br from-indigo-600 to-purple-700 text-white shadow-md flex flex-col items-center justify-center text-center cursor-pointer transition-all hover:scale-[1.01]"
                    >
                      <span className="text-[10px] font-bold tracking-wider uppercase bg-white/20 px-2.5 py-0.5 rounded-full mb-3">
                        {isFlipped ? 'Answer' : 'Question (Click to reveal)'}
                      </span>
                      <p className="text-base font-bold leading-relaxed max-w-md">
                        {isFlipped
                          ? explanationResult.flashcards[currentFlashcardIdx].answer
                          : explanationResult.flashcards[currentFlashcardIdx].question}
                      </p>
                    </div>
                  </div>
                )}

                {/* Self Assessment Practice Quiz */}
                {explanationResult.practiceQuiz && explanationResult.practiceQuiz.length > 0 && (
                  <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
                    <h4 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-2">
                      <HelpCircle className="w-4 h-4 text-indigo-600" />
                      <span>Practice Self-Assessment Quiz</span>
                    </h4>

                    <div className="space-y-4">
                      {explanationResult.practiceQuiz.map((q, qIdx) => {
                        const selectedOpt = quizAnswers[qIdx];
                        const isAnswered = selectedOpt !== undefined;
                        const isCorrect = selectedOpt === q.correctAnswer;

                        return (
                          <div key={qIdx} className="p-4 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-2">
                            <p className="text-xs font-bold text-slate-900 dark:text-slate-100">
                              {qIdx + 1}. {q.question}
                            </p>

                            <div className="space-y-1.5 pt-1">
                              {q.options.map((opt, oIdx) => {
                                const isThisSelected = selectedOpt === oIdx;
                                let btnStyle = 'border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800';

                                if (isAnswered) {
                                  if (oIdx === q.correctAnswer) {
                                    btnStyle = 'bg-emerald-100 dark:bg-emerald-950/80 border-emerald-300 text-emerald-800 dark:text-emerald-200 font-semibold';
                                  } else if (isThisSelected && !isCorrect) {
                                    btnStyle = 'bg-rose-100 dark:bg-rose-950/80 border-rose-300 text-rose-800 dark:text-rose-200';
                                  }
                                }

                                return (
                                  <button
                                    key={oIdx}
                                    onClick={() =>
                                      setQuizAnswers((prev) => ({ ...prev, [qIdx]: oIdx }))
                                    }
                                    className={`w-full text-left p-2.5 rounded-lg border text-xs transition-all ${btnStyle}`}
                                  >
                                    {opt}
                                  </button>
                                );
                              })}
                            </div>

                            {isAnswered && (
                              <p className="text-[11px] text-slate-600 dark:text-slate-400 italic pt-1 border-t border-slate-200 dark:border-slate-800">
                                Explanation: {q.explanation}
                              </p>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: AI STUDY BUDDY CHAT */}
      {activeTab === 'study_chat' && (
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col min-h-[500px]">
          {/* Quick Prompts Bar */}
          <div className="pb-4 mb-4 border-b border-slate-200 dark:border-slate-800">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 block mb-2">
              Suggested Study Questions:
            </span>
            <div className="flex flex-wrap gap-2">
              {[
                'How do I study for a math exam efficiently?',
                'Explain the Feynman Technique in 3 steps.',
                'Give me a 5-day cramming checklist for history.',
                'How to overcome academic burnout?',
              ].map((promptText, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setUserChatInput(promptText);
                  }}
                  className="px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-100 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 text-xs hover:bg-indigo-100 transition-all"
                >
                  {promptText}
                </button>
              ))}
            </div>
          </div>

          {/* Chat Messages Log */}
          <div className="flex-1 space-y-4 overflow-y-auto max-h-[400px] pr-2 mb-4">
            {chatMessages.map((msg) => {
              const isUser = msg.role === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex items-start gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
                >
                  {!isUser && (
                    <div className="w-8 h-8 rounded-full bg-purple-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                      <Sparkles className="w-4 h-4" />
                    </div>
                  )}

                  <div
                    className={`max-w-xl p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                      isUser
                        ? 'bg-indigo-600 text-white rounded-br-none'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-bl-none'
                    }`}
                  >
                    <p className="whitespace-pre-line">{msg.content}</p>
                    <span className="text-[10px] opacity-70 block text-right mt-1.5">
                      {msg.timestamp}
                    </span>
                  </div>

                  {isUser && (
                    <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center shrink-0">
                      You
                    </div>
                  )}
                </div>
              );
            })}

            {isSendingChat && (
              <div className="flex items-center space-x-2 text-xs text-slate-500 dark:text-slate-400 italic">
                <Sparkles className="w-4 h-4 animate-spin text-indigo-500" />
                <span>StudyMate AI is typing...</span>
              </div>
            )}
          </div>

          {/* Chat Input Bar */}
          <form onSubmit={handleSendChat} className="flex items-center space-x-2 pt-2 border-t border-slate-200 dark:border-slate-800">
            <input
              type="text"
              value={userChatInput}
              onChange={(e) => setUserChatInput(e.target.value)}
              placeholder="Ask anything about your courses, memory techniques, or study tips..."
              className="flex-1 px-4 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
            />
            <button
              type="submit"
              disabled={isSendingChat || !userChatInput.trim()}
              className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-500/20 disabled:opacity-50 transition-all"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
