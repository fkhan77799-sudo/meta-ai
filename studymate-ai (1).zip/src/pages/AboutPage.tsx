import React from 'react';
import {
  GraduationCap,
  Sparkles,
  Code2,
  CheckCircle2,
  BookOpen,
  Calendar,
  Layers,
  Brain,
  Terminal,
} from 'lucide-react';

export const AboutPage: React.FC = () => {
  return (
    <div className="space-y-6 pb-12 animate-fadeIn max-w-4xl mx-auto">
      {/* Header Banner */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-indigo-600 via-indigo-700 to-purple-700 text-white shadow-xl text-center space-y-3">
        <div className="w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center mx-auto border border-white/20">
          <GraduationCap className="w-8 h-8 text-amber-300" />
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          About StudyMate AI
        </h2>
        <p className="text-xs sm:text-sm text-indigo-100 max-w-xl mx-auto leading-relaxed">
          An original student capstone project developed for an advanced AI Application Development Course.
        </p>
      </div>

      {/* Problem Statement & Solution */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-2">
          <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            <span>The Student Problem</span>
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            Students frequently forget upcoming assignment deadlines, struggle to structure their daily study sessions efficiently, and lack personalized academic guidance when encountering complex, dense course material.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-2">
          <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>The StudyMate AI Solution</span>
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            StudyMate AI combines deadline tracking and Pomodoro focus timers with Google Gemini AI to provide structured exam roadmaps, intuitive analogies for complex topics, and interactive self-assessment quizzes.
          </p>
        </div>
      </div>

      {/* Feature Architecture Matrix */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
          <Layers className="w-4 h-4 text-indigo-600" />
          <span>Core Capabilities & Features</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-1">
            <div className="flex items-center space-x-2 font-bold text-slate-900 dark:text-slate-100">
              <Sparkles className="w-4 h-4 text-indigo-500" />
              <span>AI Study Assistant (Gemini API)</span>
            </div>
            <p className="text-slate-600 dark:text-slate-400">
              Generates multi-day exam study plans, explains difficult concepts with real-world metaphors, and creates interactive flashcards & quizzes.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-1">
            <div className="flex items-center space-x-2 font-bold text-slate-900 dark:text-slate-100">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>Study Tasks & Homework Manager</span>
            </div>
            <p className="text-slate-600 dark:text-slate-400">
              Complete task management with priority tagging (High/Medium/Low), search filtering, subject tags, and estimated time tracking.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-1">
            <div className="flex items-center space-x-2 font-bold text-slate-900 dark:text-slate-100">
              <BookOpen className="w-4 h-4 text-rose-500" />
              <span>Assignment & Grade Tracker</span>
            </div>
            <p className="text-slate-600 dark:text-slate-400">
              Track course term papers, countdown due dates, monitor grade weights %, and log assignment scores.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-1">
            <div className="flex items-center space-x-2 font-bold text-slate-900 dark:text-slate-100">
              <Calendar className="w-4 h-4 text-indigo-500" />
              <span>Daily Interactive Planner & Pomodoro</span>
            </div>
            <p className="text-slate-600 dark:text-slate-400">
              Block time slots, use the 25-minute Pomodoro focus timer with Web Audio tones, and export AI schedules directly into your daily view.
            </p>
          </div>
        </div>
      </div>

      {/* Tech Stack Specs */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
          <Code2 className="w-4 h-4 text-indigo-600" />
          <span>Technical Stack Specifications</span>
        </h3>

        <div className="flex flex-wrap gap-2 text-xs">
          {[
            'React 19',
            'TypeScript 5.8',
            'Vite 6',
            'Express 4 Backend',
            '@google/genai SDK (Gemini 3.6 Flash)',
            'Tailwind CSS v4',
            'Lucide React Icons',
            'LocalStorage Persistence',
            'Web Audio API Synth',
          ].map((tech, i) => (
            <span
              key={i}
              className="px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200/60 dark:border-indigo-800/60 text-indigo-800 dark:text-indigo-300 font-semibold"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
