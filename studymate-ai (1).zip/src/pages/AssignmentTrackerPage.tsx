import React, { useState } from 'react';
import {
  BookOpen,
  Plus,
  Calendar,
  Award,
  Clock,
  Trash2,
  Edit2,
  AlertTriangle,
  CheckCircle,
  Percent,
} from 'lucide-react';
import { Assignment, AssignmentStatus } from '../types';

interface AssignmentTrackerPageProps {
  assignments: Assignment[];
  onAddAssignment: () => void;
  onEditAssignment: (assignment: Assignment) => void;
  onDeleteAssignment: (assignmentId: string) => void;
}

export const AssignmentTrackerPage: React.FC<AssignmentTrackerPageProps> = ({
  assignments,
  onAddAssignment,
  onEditAssignment,
  onDeleteAssignment,
}) => {
  const [courseFilter, setCourseFilter] = useState('all');

  const courses = Array.from(new Set(assignments.map((a) => a.course))).filter(Boolean);

  const filteredAssignments = assignments.filter((a) =>
    courseFilter === 'all' ? true : a.course === courseFilter
  );

  // Helper function to calculate days remaining
  const getDaysRemaining = (dueDateStr: string) => {
    const due = new Date(dueDateStr);
    const now = new Date();
    due.setHours(0, 0, 0, 0);
    now.setHours(0, 0, 0, 0);
    const diffTime = due.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const getStatusBadge = (status: AssignmentStatus) => {
    switch (status) {
      case 'not_started':
        return 'bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300';
      case 'in_progress':
        return 'bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300';
      case 'submitted':
        return 'bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300';
      case 'graded':
        return 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300';
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-fadeIn">
      {/* Top Banner Card */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-rose-600" />
            <span>Academic Assignment & Course Tracker</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Track submission deadlines, syllabus weights, and course grades
          </p>
        </div>

        <button
          onClick={onAddAssignment}
          className="flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs sm:text-sm shadow-md shadow-rose-500/20 transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add Assignment</span>
        </button>
      </div>

      {/* Filter by Course */}
      <div className="flex items-center justify-between p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
        <div className="flex items-center space-x-2 text-xs font-semibold text-slate-700 dark:text-slate-300">
          <span>Filter Course:</span>
        </div>
        <select
          value={courseFilter}
          onChange={(e) => setCourseFilter(e.target.value)}
          className="px-3.5 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-500/50"
        >
          <option value="all">All Courses ({assignments.length})</option>
          {courses.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      {/* Grid of Assignments */}
      {filteredAssignments.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
          <BookOpen className="w-12 h-12 text-slate-400 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
            No assignments recorded
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
            Click "Add Assignment" to start tracking your term papers, lab reports, and midterm exams.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredAssignments.map((assignment) => {
            const daysLeft = getDaysRemaining(assignment.dueDate);
            const isOverdue = daysLeft < 0 && assignment.status !== 'submitted' && assignment.status !== 'graded';
            const isDueSoon = daysLeft >= 0 && daysLeft <= 3 && assignment.status !== 'submitted' && assignment.status !== 'graded';

            return (
              <div
                key={assignment.id}
                className={`p-5 rounded-2xl border transition-all flex flex-col justify-between ${
                  isOverdue
                    ? 'bg-rose-50/40 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/50'
                    : isDueSoon
                    ? 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/50'
                    : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 hover:border-rose-200 dark:hover:border-rose-900/60 shadow-sm'
                }`}
              >
                <div>
                  {/* Header badges */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold text-xs">
                      {assignment.course}
                    </span>

                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wide ${getStatusBadge(
                        assignment.status
                      )}`}
                    >
                      {assignment.status.replace('_', ' ')}
                    </span>
                  </div>

                  <h3 className="font-bold text-base text-slate-900 dark:text-slate-100 mb-1 leading-snug">
                    {assignment.title}
                  </h3>

                  {assignment.instructions && (
                    <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 mb-3">
                      {assignment.instructions}
                    </p>
                  )}
                </div>

                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  {/* Weight and Due Date */}
                  <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                    <span className="flex items-center gap-1">
                      <Percent className="w-3.5 h-3.5 text-rose-500" />
                      Grade Weight: <strong className="text-slate-800 dark:text-slate-200">{assignment.weightPercentage}%</strong>
                    </span>

                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {assignment.dueDate}
                    </span>
                  </div>

                  {/* Days remaining badge or grade display */}
                  <div className="flex items-center justify-between">
                    {assignment.status === 'graded' && assignment.gradeScore !== undefined ? (
                      <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-bold text-sm">
                        <Award className="w-4 h-4" />
                        <span>Score: {assignment.gradeScore} / {assignment.maxScore || 100}</span>
                      </div>
                    ) : isOverdue ? (
                      <span className="text-xs font-bold text-rose-600 dark:text-rose-400 flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5" /> Overdue by {Math.abs(daysLeft)} days
                      </span>
                    ) : daysLeft === 0 ? (
                      <span className="text-xs font-bold text-rose-600 dark:text-rose-400 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 animate-pulse" /> Due Today!
                      </span>
                    ) : (
                      <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                        {daysLeft} days remaining
                      </span>
                    )}

                    <div className="flex items-center space-x-1">
                      <button
                        onClick={() => onEditAssignment(assignment)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                        title="Edit Assignment"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onDeleteAssignment(assignment.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                        title="Delete Assignment"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
