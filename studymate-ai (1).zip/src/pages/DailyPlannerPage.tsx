import React from 'react';
import {
  Calendar,
  Plus,
  CheckCircle2,
  Clock,
  Trash2,
  Edit2,
  Sparkles,
  RotateCcw,
} from 'lucide-react';
import { DailyScheduleSlot, NavPage } from '../types';
import { PomodoroTimer } from '../components/PomodoroTimer';

interface DailyPlannerPageProps {
  schedule: DailyScheduleSlot[];
  onAddSlot: () => void;
  onEditSlot: (slot: DailyScheduleSlot) => void;
  onDeleteSlot: (slotId: string) => void;
  onToggleSlotCompleted: (slotId: string) => void;
  onNavigate: (page: NavPage) => void;
  onLogStudySession: (subject: string, minutes: number) => void;
}

export const DailyPlannerPage: React.FC<DailyPlannerPageProps> = ({
  schedule,
  onAddSlot,
  onEditSlot,
  onDeleteSlot,
  onToggleSlotCompleted,
  onNavigate,
  onLogStudySession,
}) => {
  const completedCount = schedule.filter((s) => s.completed).length;
  const totalSlots = schedule.length;
  const progressPercent = totalSlots > 0 ? Math.round((completedCount / totalSlots) * 100) : 0;

  return (
    <div className="space-y-6 pb-12 animate-fadeIn">
      {/* Top Banner Card */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-indigo-600" />
            <span>Daily Interactive Study Schedule</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Block time for deep work, active recall, revision, and rest intervals
          </p>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <button
            onClick={() => onNavigate('ai_assistant')}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 text-xs font-semibold hover:bg-purple-100 dark:hover:bg-purple-900 transition-all"
          >
            <Sparkles className="w-4 h-4 text-purple-500" />
            <span>Generate AI Schedule</span>
          </button>

          <button
            onClick={onAddSlot}
            className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md shadow-indigo-500/20 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add Slot</span>
          </button>
        </div>
      </div>

      {/* Grid: Planner Timeline + Pomodoro Side */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Planner Schedule Column */}
        <div className="lg:col-span-2 space-y-4">
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Schedule Progress ({completedCount}/{totalSlots} completed)
              </span>
              <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                {progressPercent}%
              </span>
            </div>

            <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden mb-6">
              <div
                className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            {/* Time Slot Cards */}
            {schedule.length === 0 ? (
              <div className="p-10 text-center rounded-xl border border-dashed border-slate-200 dark:border-slate-800">
                <Calendar className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                  No schedule blocks for today
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Click "Add Slot" or ask the AI Study Assistant to craft a study roadmap.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {schedule.map((slot) => {
                  return (
                    <div
                      key={slot.id}
                      className={`p-4 rounded-xl border transition-all flex items-start justify-between gap-4 ${
                        slot.completed
                          ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200/80 dark:border-emerald-800/50'
                          : 'bg-white dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-800'
                      }`}
                    >
                      <div className="flex items-start space-x-3.5">
                        <button
                          onClick={() => onToggleSlotCompleted(slot.id)}
                          className="mt-1 focus:outline-none"
                        >
                          {slot.completed ? (
                            <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                          ) : (
                            <div className="w-5 h-5 rounded-md border-2 border-slate-300 dark:border-slate-600 hover:border-indigo-500 transition-colors" />
                          )}
                        </button>

                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="text-xs font-bold font-mono px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                              {slot.timeSlot}
                            </span>
                            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300">
                              {slot.subject}
                            </span>
                          </div>

                          <h4
                            className={`text-sm font-bold mt-1.5 ${
                              slot.completed
                                ? 'line-through text-slate-400 dark:text-slate-500'
                                : 'text-slate-900 dark:text-slate-100'
                            }`}
                          >
                            {slot.topic}
                          </h4>

                          {slot.notes && (
                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                              {slot.notes}
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center space-x-1 shrink-0">
                        <button
                          onClick={() => onEditSlot(slot)}
                          className="p-1.5 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                          title="Edit Slot"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onDeleteSlot(slot.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                          title="Delete Slot"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Pomodoro Timer Column */}
        <div>
          <PomodoroTimer onSessionComplete={onLogStudySession} />
        </div>
      </div>
    </div>
  );
};
