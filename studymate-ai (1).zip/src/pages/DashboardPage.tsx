import React from 'react';
import {
  CheckCircle2,
  Clock,
  BookOpen,
  Sparkles,
  TrendingUp,
  Plus,
  ArrowRight,
  Target,
  Flame,
  Award,
} from 'lucide-react';
import { StudyTask, Assignment, DailyScheduleSlot, UserSettings, NavPage } from '../types';
import { PomodoroTimer } from '../components/PomodoroTimer';

interface DashboardPageProps {
  tasks: StudyTask[];
  assignments: Assignment[];
  schedule: DailyScheduleSlot[];
  settings: UserSettings;
  onNavigate: (page: NavPage) => void;
  onToggleTaskStatus: (taskId: string) => void;
  onOpenAddTask: () => void;
  onLogStudySession: (subject: string, minutes: number) => void;
}

const QUOTES = [
  "\"Education is the most powerful weapon which you can use to change the world.\" — Nelson Mandela",
  "\"Success is the sum of small efforts, repeated day in and day out.\" — Robert Collier",
  "\"The secret of getting ahead is getting started.\" — Mark Twain",
  "\"Small daily improvements over time lead to stunning results.\" — Robin Sharma",
];

export const DashboardPage: React.FC<DashboardPageProps> = ({
  tasks,
  assignments,
  schedule,
  settings,
  onNavigate,
  onToggleTaskStatus,
  onOpenAddTask,
  onLogStudySession,
}) => {
  const [randomQuote] = React.useState(
    () => QUOTES[Math.floor(Math.random() * QUOTES.length)]
  );

  const completedTasksCount = tasks.filter((t) => t.status === 'completed').length;
  const totalTasksCount = tasks.length;
  const taskProgressPercent = totalTasksCount > 0 ? Math.round((completedTasksCount / totalTasksCount) * 100) : 0;

  const pendingTasks = tasks.filter((t) => t.status !== 'completed');
  const upcomingAssignments = assignments.filter((a) => a.status !== 'graded');
  const completedScheduleSlots = schedule.filter((s) => s.completed).length;
  const scheduleProgressPercent = schedule.length > 0 ? Math.round((completedScheduleSlots / schedule.length) * 100) : 0;

  // Calculate estimated remaining study time in hours
  const totalRemainingMins = pendingTasks.reduce((acc, t) => acc + (t.estimatedMinutes || 30), 0);
  const remainingHours = (totalRemainingMins / 60).toFixed(1);

  return (
    <div className="space-y-6 pb-12 animate-fadeIn">
      {/* Welcome Banner */}
      <div className="relative p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-indigo-600 via-indigo-700 to-purple-700 text-white shadow-xl shadow-indigo-500/10 overflow-hidden">
        {/* Decorative Circles */}
        <div className="absolute -top-12 -right-12 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-purple-500/20 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-xl space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md text-xs font-semibold text-indigo-100 border border-white/20">
              <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin-slow" />
              <span>AI Study Companion Ready</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Ready to crush your study goals today, {settings.userName}?
            </h2>
            <p className="text-sm text-indigo-100/90 italic pt-1">
              {randomQuote}
            </p>
          </div>

          <div className="flex flex-wrap sm:flex-nowrap gap-3 shrink-0">
            <button
              onClick={onOpenAddTask}
              className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-white text-indigo-700 hover:bg-indigo-50 font-semibold text-xs sm:text-sm shadow-md transition-all active:scale-95"
            >
              <Plus className="w-4 h-4 text-indigo-600" />
              <span>Add Study Task</span>
            </button>
            <button
              onClick={() => onNavigate('ai_assistant')}
              className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-purple-500/30 hover:bg-purple-500/40 backdrop-blur-md border border-white/20 text-white font-semibold text-xs sm:text-sm transition-all"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Launch AI Assistant</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Tasks Progress */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Task Completion</span>
            <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between mb-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-slate-100">
              {completedTasksCount} / {totalTasksCount}
            </span>
            <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
              {taskProgressPercent}%
            </span>
          </div>
          {/* Progress Bar */}
          <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              className="bg-indigo-600 h-full rounded-full transition-all duration-500"
              style={{ width: `${taskProgressPercent}%` }}
            />
          </div>
        </div>

        {/* Metric 2: Pending Work Time */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Est. Remaining Time</span>
            <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900 dark:text-slate-100">
              {remainingHours} hrs
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              {pendingTasks.length} tasks pending
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
            Goal: {settings.dailyGoalHours} hrs study today
          </p>
        </div>

        {/* Metric 3: Active Assignments */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Assignments Due</span>
            <div className="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900 dark:text-slate-100">
              {upcomingAssignments.length}
            </span>
            <button
              onClick={() => onNavigate('assignments')}
              className="text-xs font-medium text-rose-600 dark:text-rose-400 hover:underline flex items-center gap-0.5"
            >
              View list <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
            Target GPA: <span className="font-semibold text-slate-800 dark:text-slate-200">{settings.targetGpa}</span>
          </p>
        </div>

        {/* Metric 4: Daily Schedule Progress */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Planner Completion</span>
            <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
              <Flame className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between mb-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-slate-100">
              {completedScheduleSlots} / {schedule.length}
            </span>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
              {scheduleProgressPercent}%
            </span>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              className="bg-emerald-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${scheduleProgressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Main Grid Section: Tasks & Pomodoro */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 cols): Pending Tasks & Daily Planner Preview */}
        <div className="lg:col-span-2 space-y-6">
          {/* Priority Study Tasks */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-slate-100 text-lg">
                  Priority Tasks
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Focus on these high-impact study activities
                </p>
              </div>
              <button
                onClick={() => onNavigate('tasks')}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
              >
                View all tasks <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {pendingTasks.length === 0 ? (
              <div className="text-center py-8 px-4 rounded-xl border border-dashed border-slate-200 dark:border-slate-800">
                <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                  All study tasks completed!
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Add new tasks or generate an AI study plan to stay ahead.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {pendingTasks.slice(0, 4).map((task) => (
                  <div
                    key={task.id}
                    className="flex items-start justify-between p-3.5 rounded-xl border border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-slate-100/60 dark:hover:bg-slate-800/80 transition-all"
                  >
                    <div className="flex items-start space-x-3">
                      <input
                        type="checkbox"
                        checked={task.status === 'completed'}
                        onChange={() => onToggleTaskStatus(task.id)}
                        className="mt-1 w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                      />
                      <div>
                        <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                          {task.title}
                        </h4>
                        <div className="flex flex-wrap items-center gap-2 mt-1 text-xs text-slate-500 dark:text-slate-400">
                          <span className="px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-medium">
                            {task.subject}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" /> {task.estimatedMinutes} mins
                          </span>
                          <span>Due: {task.dueDate}</span>
                        </div>
                      </div>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase tracking-wide shrink-0 ${
                        task.priority === 'high'
                          ? 'bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300'
                          : task.priority === 'medium'
                          ? 'bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300'
                          : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {task.priority}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Today's Planner Timeline Preview */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-slate-100 text-lg">
                  Today's Planner Schedule
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Your structured time slots for today
                </p>
              </div>
              <button
                onClick={() => onNavigate('planner')}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
              >
                Open full planner <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3">
              {schedule.slice(0, 3).map((slot) => (
                <div
                  key={slot.id}
                  className={`p-3.5 rounded-xl border transition-all flex items-center justify-between ${
                    slot.completed
                      ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200/60 dark:border-emerald-800/50'
                      : 'bg-white dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-800'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className="text-xs font-bold font-mono px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {slot.timeSlot}
                    </span>
                    <div>
                      <h4 className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-slate-100">
                        {slot.subject} — <span className="font-normal text-slate-600 dark:text-slate-300">{slot.topic}</span>
                      </h4>
                    </div>
                  </div>

                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                      slot.completed
                        ? 'bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {slot.completed ? 'Completed' : 'Upcoming'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (1 col): Pomodoro Timer Widget & AI Launch Card */}
        <div className="space-y-6">
          <PomodoroTimer onSessionComplete={onLogStudySession} />

          {/* AI Feature Callout Card */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-purple-900 via-indigo-900 to-slate-900 text-white shadow-lg relative overflow-hidden">
            <div className="flex items-center gap-2 text-amber-300 text-xs font-bold mb-2">
              <Sparkles className="w-4 h-4" />
              <span>AI POWERED ASSISTANT</span>
            </div>
            <h3 className="text-lg font-bold mb-2">
              Need help understanding complex topics?
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              Ask Gemini to break down difficult concepts into simple analogies, generate practice flashcards, or create a personalized exam study roadmap.
            </p>
            <button
              onClick={() => onNavigate('ai_assistant')}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 font-semibold text-xs text-white shadow-md shadow-indigo-500/30 flex items-center justify-center gap-2 transition-all"
            >
              <Sparkles className="w-4 h-4" />
              <span>Try AI Study Assistant</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
