import React from 'react';
import { Sun, Moon, Sparkles, User, Bell, CheckCircle2 } from 'lucide-react';
import { UserSettings } from '../types';

interface HeaderProps {
  currentPageTitle: string;
  settings: UserSettings;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  pendingTasksCount: number;
  upcomingAssignmentsCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentPageTitle,
  settings,
  darkMode,
  onToggleDarkMode,
  pendingTasksCount,
  upcomingAssignmentsCount,
}) => {
  return (
    <header className="sticky top-0 z-30 flex items-center justify-between px-4 py-3.5 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 transition-colors">
      <div className="flex items-center space-x-3">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <span>{currentPageTitle}</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 hidden sm:block">
            Welcome back, <span className="font-semibold text-indigo-600 dark:text-indigo-400">{settings.userName}</span> • Target GPA: {settings.targetGpa}
          </p>
        </div>
      </div>

      <div className="flex items-center space-x-2 sm:space-x-3">
        {/* Active AI Status Pill */}
        <div className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950/50 dark:to-purple-950/50 border border-indigo-200/60 dark:border-indigo-800/60 text-xs font-medium text-indigo-700 dark:text-indigo-300">
          <Sparkles className="w-3.5 h-3.5 text-indigo-500 animate-pulse" />
          <span>Gemini AI Active</span>
        </div>

        {/* Quick Pending Counter */}
        <div className="hidden sm:flex items-center gap-2 text-xs">
          {pendingTasksCount > 0 && (
            <span className="px-2.5 py-1 rounded-md bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-300 font-medium flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              {pendingTasksCount} tasks pending
            </span>
          )}
          {upcomingAssignmentsCount > 0 && (
            <span className="px-2.5 py-1 rounded-md bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 font-medium flex items-center gap-1">
              <Bell className="w-3 h-3" />
              {upcomingAssignmentsCount} due soon
            </span>
          )}
        </div>

        {/* Dark Mode Toggle */}
        <button
          onClick={onToggleDarkMode}
          className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
          title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          aria-label="Toggle Dark Mode"
        >
          {darkMode ? (
            <Sun className="w-5 h-5 text-amber-400" />
          ) : (
            <Moon className="w-5 h-5 text-slate-700" />
          )}
        </button>

        {/* Profile Chip */}
        <div className="flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-800">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white font-semibold text-xs shadow-sm">
            {settings.userName.split(' ').map((n) => n[0]).join('') || 'S'}
          </div>
        </div>
      </div>
    </header>
  );
};
