import React, { useState, useEffect } from 'react';
import { NavPage, StudyTask, Assignment, DailyScheduleSlot, UserSettings, StudyLog } from './types';
import {
  getStoredTasks,
  saveTasks,
  getStoredAssignments,
  saveAssignments,
  getStoredSchedule,
  saveSchedule,
  getStoredSettings,
  saveSettings,
  getStoredStudyLogs,
  saveStudyLogs,
  resetAllData,
} from './utils/storage';

import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { TaskModal } from './components/TaskModal';
import { AssignmentModal } from './components/AssignmentModal';
import { ScheduleModal } from './components/ScheduleModal';

import { DashboardPage } from './pages/DashboardPage';
import { StudyTasksPage } from './pages/StudyTasksPage';
import { AssignmentTrackerPage } from './pages/AssignmentTrackerPage';
import { DailyPlannerPage } from './pages/DailyPlannerPage';
import { AIAssistantPage } from './pages/AIAssistantPage';
import { SettingsPage } from './pages/SettingsPage';
import { AboutPage } from './pages/AboutPage';

export default function App() {
  const [activePage, setActivePage] = useState<NavPage>('dashboard');

  // Core Data State
  const [tasks, setTasks] = useState<StudyTask[]>(getStoredTasks);
  const [assignments, setAssignments] = useState<Assignment[]>(getStoredAssignments);
  const [schedule, setSchedule] = useState<DailyScheduleSlot[]>(getStoredSchedule);
  const [settings, setSettings] = useState<UserSettings>(getStoredSettings);
  const [studyLogs, setStudyLogs] = useState<StudyLog[]>(getStoredStudyLogs);

  // Dark Mode State
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const stored = localStorage.getItem('studymate_dark_mode');
    if (stored !== null) return stored === 'true';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  // Modals state
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<StudyTask | null>(null);

  const [isAssignmentModalOpen, setIsAssignmentModalOpen] = useState(false);
  const [editingAssignment, setEditingAssignment] = useState<Assignment | null>(null);

  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [editingSlot, setEditingSlot] = useState<DailyScheduleSlot | null>(null);

  // Apply dark mode class to document root
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('studymate_dark_mode', String(darkMode));
  }, [darkMode]);

  // Sync state to local storage whenever changed
  useEffect(() => {
    saveTasks(tasks);
  }, [tasks]);

  useEffect(() => {
    saveAssignments(assignments);
  }, [assignments]);

  useEffect(() => {
    saveSchedule(schedule);
  }, [schedule]);

  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  useEffect(() => {
    saveStudyLogs(studyLogs);
  }, [studyLogs]);

  // Handlers for Tasks
  const handleSaveTask = (taskData: Omit<StudyTask, 'id' | 'createdAt'> & { id?: string }) => {
    if (taskData.id) {
      // Edit existing
      setTasks((prev) =>
        prev.map((t) => (t.id === taskData.id ? ({ ...t, ...taskData } as StudyTask) : t))
      );
    } else {
      // Add new
      const newTask: StudyTask = {
        ...taskData,
        id: `task-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      setTasks((prev) => [newTask, ...prev]);
    }
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
  };

  const handleToggleTaskStatus = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const nextStatus = t.status === 'completed' ? 'todo' : 'completed';
          return { ...t, status: nextStatus };
        }
        return t;
      })
    );
  };

  // Handlers for Assignments
  const handleSaveAssignment = (assignmentData: Omit<Assignment, 'id'> & { id?: string }) => {
    if (assignmentData.id) {
      setAssignments((prev) =>
        prev.map((a) => (a.id === assignmentData.id ? ({ ...a, ...assignmentData } as Assignment) : a))
      );
    } else {
      const newAssg: Assignment = {
        ...assignmentData,
        id: `assg-${Date.now()}`,
      };
      setAssignments((prev) => [newAssg, ...prev]);
    }
  };

  const handleDeleteAssignment = (assignmentId: string) => {
    setAssignments((prev) => prev.filter((a) => a.id !== assignmentId));
  };

  // Handlers for Daily Schedule
  const handleSaveScheduleSlot = (slotData: Omit<DailyScheduleSlot, 'id'> & { id?: string }) => {
    if (slotData.id) {
      setSchedule((prev) =>
        prev.map((s) => (s.id === slotData.id ? ({ ...s, ...slotData } as DailyScheduleSlot) : s))
      );
    } else {
      const newSlot: DailyScheduleSlot = {
        ...slotData,
        id: `slot-${Date.now()}`,
      };
      setSchedule((prev) => [...prev, newSlot]);
    }
  };

  const handleDeleteScheduleSlot = (slotId: string) => {
    setSchedule((prev) => prev.filter((s) => s.id !== slotId));
  };

  const handleToggleSlotCompleted = (slotId: string) => {
    setSchedule((prev) =>
      prev.map((s) => (s.id === slotId ? { ...s, completed: !s.completed } : s))
    );
  };

  // Handler for adding multiple AI generated schedule slots
  const handleAddMultipleSlots = (newSlots: DailyScheduleSlot[]) => {
    setSchedule((prev) => [...prev, ...newSlots]);
  };

  // Handler for Pomodoro study session log
  const handleLogStudySession = (subject: string, durationMinutes: number) => {
    const newLog: StudyLog = {
      id: `log-${Date.now()}`,
      subject,
      durationMinutes,
      date: new Date().toISOString().split('T')[0],
    };
    setStudyLogs((prev) => [newLog, ...prev]);
  };

  // Reset Data Handler
  const handleResetData = () => {
    resetAllData();
    window.location.reload();
  };

  const pendingTasksCount = tasks.filter((t) => t.status !== 'completed').length;
  const dueAssignmentsCount = assignments.filter((a) => a.status !== 'graded').length;

  const pageTitles: Record<NavPage, string> = {
    dashboard: 'Dashboard',
    tasks: 'Study Tasks',
    assignments: 'Assignment Tracker',
    planner: 'Daily Planner',
    ai_assistant: 'AI Study Assistant',
    settings: 'Settings',
    about: 'About StudyMate AI',
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col lg:flex-row font-sans transition-colors">
      {/* Sidebar Navigation */}
      <Sidebar
        activePage={activePage}
        onNavigate={setActivePage}
        pendingTasksCount={pendingTasksCount}
        dueAssignmentsCount={dueAssignmentsCount}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        <Header
          currentPageTitle={pageTitles[activePage]}
          settings={settings}
          darkMode={darkMode}
          onToggleDarkMode={() => setDarkMode(!darkMode)}
          pendingTasksCount={pendingTasksCount}
          upcomingAssignmentsCount={dueAssignmentsCount}
        />

        <main className="flex-1 p-4 sm:p-6 md:p-8 max-w-7xl w-full mx-auto">
          {activePage === 'dashboard' && (
            <DashboardPage
              tasks={tasks}
              assignments={assignments}
              schedule={schedule}
              settings={settings}
              onNavigate={setActivePage}
              onToggleTaskStatus={handleToggleTaskStatus}
              onOpenAddTask={() => {
                setEditingTask(null);
                setIsTaskModalOpen(true);
              }}
              onLogStudySession={handleLogStudySession}
            />
          )}

          {activePage === 'tasks' && (
            <StudyTasksPage
              tasks={tasks}
              onAddTask={() => {
                setEditingTask(null);
                setIsTaskModalOpen(true);
              }}
              onEditTask={(task) => {
                setEditingTask(task);
                setIsTaskModalOpen(true);
              }}
              onDeleteTask={handleDeleteTask}
              onToggleTaskStatus={handleToggleTaskStatus}
            />
          )}

          {activePage === 'assignments' && (
            <AssignmentTrackerPage
              assignments={assignments}
              onAddAssignment={() => {
                setEditingAssignment(null);
                setIsAssignmentModalOpen(true);
              }}
              onEditAssignment={(assignment) => {
                setEditingAssignment(assignment);
                setIsAssignmentModalOpen(true);
              }}
              onDeleteAssignment={handleDeleteAssignment}
            />
          )}

          {activePage === 'planner' && (
            <DailyPlannerPage
              schedule={schedule}
              onAddSlot={() => {
                setEditingSlot(null);
                setIsScheduleModalOpen(true);
              }}
              onEditSlot={(slot) => {
                setEditingSlot(slot);
                setIsScheduleModalOpen(true);
              }}
              onDeleteSlot={handleDeleteScheduleSlot}
              onToggleSlotCompleted={handleToggleSlotCompleted}
              onNavigate={setActivePage}
              onLogStudySession={handleLogStudySession}
            />
          )}

          {activePage === 'ai_assistant' && (
            <AIAssistantPage
              onAddScheduleSlots={handleAddMultipleSlots}
            />
          )}

          {activePage === 'settings' && (
            <SettingsPage
              settings={settings}
              onUpdateSettings={setSettings}
              onResetData={handleResetData}
              darkMode={darkMode}
              onToggleDarkMode={() => setDarkMode(!darkMode)}
            />
          )}

          {activePage === 'about' && <AboutPage />}
        </main>
      </div>

      {/* Modals */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => setIsTaskModalOpen(false)}
        onSave={handleSaveTask}
        initialTask={editingTask}
      />

      <AssignmentModal
        isOpen={isAssignmentModalOpen}
        onClose={() => setIsAssignmentModalOpen(false)}
        onSave={handleSaveAssignment}
        initialAssignment={editingAssignment}
      />

      <ScheduleModal
        isOpen={isScheduleModalOpen}
        onClose={() => setIsScheduleModalOpen(false)}
        onSave={handleSaveScheduleSlot}
        initialSlot={editingSlot}
      />
    </div>
  );
}
