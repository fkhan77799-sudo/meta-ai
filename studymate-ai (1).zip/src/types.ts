export type Priority = 'low' | 'medium' | 'high';

export type NavPage =
  | 'dashboard'
  | 'tasks'
  | 'assignments'
  | 'planner'
  | 'ai_assistant'
  | 'settings'
  | 'about';

export type TaskStatus = 'todo' | 'in_progress' | 'completed';

export interface StudyTask {
  id: string;
  title: string;
  subject: string;
  dueDate: string; // ISO string
  estimatedMinutes: number;
  priority: Priority;
  status: TaskStatus;
  notes?: string;
  createdAt: string;
}

export type AssignmentStatus = 'not_started' | 'in_progress' | 'submitted' | 'graded';

export interface Assignment {
  id: string;
  title: string;
  course: string;
  dueDate: string; // ISO date string YYYY-MM-DD
  weightPercentage: number; // e.g. 15 for 15% of final grade
  status: AssignmentStatus;
  gradeScore?: number; // e.g., 92
  maxScore?: number; // e.g., 100
  instructions?: string;
}

export interface DailyScheduleSlot {
  id: string;
  timeSlot: string; // e.g. "09:00 AM - 10:00 AM"
  subject: string;
  topic: string;
  completed: boolean;
  notes?: string;
}

export interface UserSettings {
  userName: string;
  email?: string;
  schoolOrCourse: string;
  targetGpa: string;
  dailyGoalHours: number;
  defaultPomodoroWork: number; // minutes
  defaultPomodoroBreak: number; // minutes
  theme: 'light' | 'dark' | 'system';
  notificationsEnabled: boolean;
  aiStylePreference: string;
}

export interface Flashcard {
  question: string;
  answer: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface TopicExplanation {
  topic: string;
  summary: string;
  explanation: string;
  analogies: string[];
  keyTakeaways: string[];
  flashcards: Flashcard[];
  practiceQuiz: QuizQuestion[];
}

export interface StudyPlanScheduleItem {
  day: string;
  time: string;
  focus: string;
  activity: string;
}

export interface AIStudyPlan {
  title: string;
  summary: string;
  schedule: StudyPlanScheduleItem[];
  tips: string[];
  milestones?: string[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface StudyLog {
  id: string;
  subject: string;
  durationMinutes: number;
  date: string; // YYYY-MM-DD
}
