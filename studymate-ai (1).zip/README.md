# StudyMate AI 🎓✨

**StudyMate AI** is a complete, production-ready AI-powered study companion and academic organizer built for students. It solves common academic struggles—forgetting assignments, disorganized schedules, and conceptual roadblocks—by unifying task management, deadline tracking, and an interactive Pomodoro timer with the Google Gemini AI API.

---

## 🌟 Key Features

### 📊 1. Student Dashboard
- **Progress Tracking**: Real-time visual progress bars for study tasks and daily schedule completion.
- **Estimated Remaining Time**: Calculates total study time required for pending tasks.
- **Motivational Quotes**: Rotating academic motivation quotes.
- **Quick Actions**: One-click access to task creation and AI Study Hub.

### 📝 2. Study Tasks & Homework Manager
- **Full CRUD**: Create, edit, search, and delete study tasks.
- **Prioritization**: Categorize tasks by **High**, **Medium**, or **Low** priority.
- **Subject Tagging & Filters**: Filter tasks by subject, completion status (To Do, In Progress, Completed), or search keywords.
- **Time Estimation**: Track estimated completion time per task in minutes.

### 📚 3. Academic Assignment Tracker
- **Course Deadlines**: Track midterm exams, term papers, and lab reports.
- **Weight Calculator**: Monitor grade weights (%) across course syllabi.
- **Grade Score Logger**: Record scores achieved out of max possible points.
- **Countdown Badges**: Visual alerts for overdue, due today, or upcoming submissions.

### 📅 4. Daily Interactive Planner & Pomodoro Focus Timer
- **Time Block Planner**: Organize hourly study slots for deep work and revision.
- **Pomodoro Focus Timer**: Built-in 25-min focus sessions and 5-min break timers.
- **Web Audio Tones**: Auditory completion alarms generated via Web Audio API.
- **Session Logger**: Automatically logs completed study minutes to local history.

### 🤖 5. AI Study Hub (Powered by Google Gemini 3.6 Flash)
- **AI Study Plan Generator**: Custom inputs for subject, goal grade, exam deadline, and available hours produce a multi-day structured roadmap exportable directly to the Daily Planner.
- **AI Topic Explainer & Quiz**: Converts dense topics into intuitive real-world metaphors, step-by-step breakdowns, interactive flashcards, and a 3-question practice quiz.
- **Interactive AI Study Buddy Chatbot**: Live interactive Q&A assistant with suggested study technique prompts (e.g., Feynman Technique, Pomodoro strategies, exam checklists).

### 🌓 6. Customization & Persistence
- **Light/Dark Mode**: Seamless, system-aware theme toggle with smooth CSS transitions.
- **LocalStorage Sync**: Persistent state storage for offline use.
- **Backup & Restore**: Export all study data to a JSON backup file or reset data to defaults.

---

## 🛠️ Tech Stack & Architecture

- **Frontend**: React 19, TypeScript, Vite 6, Tailwind CSS v4, Lucide React Icons
- **Backend**: Node.js, Express 4, `tsx`
- **AI SDK**: `@google/genai` (Google Gemini 3.6 Flash)
- **Audio**: Web Audio API Synth Oscillator

---

## 🚀 Installation & Running Locally

### Prerequisites
- Node.js (v18 or higher)
- npm or yarn

### Steps

1. **Clone the repository and install dependencies**:
   ```bash
   npm install
   ```

2. **Configure Environment Variables**:
   Create a `.env` file in the root directory (or use `.env.example`):
   ```env
   GEMINI_API_KEY="YOUR_GEMINI_API_KEY"
   ```

3. **Start the Development Server**:
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000` in your browser.

4. **Production Build**:
   ```bash
   npm run build
   npm start
   ```

---

## 📜 License
Apache-2.0 License. Designed for students and AI course projects.
